const quizData = [
    {
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Text Machine Language",
            "Hyperlinks Text Mark Language",
            "Home Tool Markup Language"
        ],
        correct: 0
    },
    {
        question: "Which language is used for styling web pages?",
        options: ["HTML", "CSS", "JavaScript", "Python"],
        correct: 1
    },
    {
        question: "Which is used to add interactivity to a website?",
        options: ["HTML", "CSS", "Java", "JavaScript"],
        correct: 3
    }
];

let currentQuestion = 0;
let score = 0;
let selectedOption = null;

const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const quizEl = document.getElementById("quiz");
const resultEl = document.getElementById("result");
const scoreText = document.getElementById("scoreText");

loadQuestion();

function loadQuestion() {
    let q = quizData[currentQuestion];
    questionEl.textContent = q.question;
    optionsEl.innerHTML = "";
    selectedOption = null;

    for (let i = 0; i < q.options.length; i++) {
        let li = document.createElement("li");
        li.textContent = q.options[i];

        li.onclick = function () {
            selectOption(li, i);
        };

        optionsEl.appendChild(li);
    }
}

function selectOption(element, index) {
    let options = document.querySelectorAll("#options li");

    // remove previous selection
    options.forEach(opt => opt.classList.remove("selected"));

    // mark new selection
    element.classList.add("selected");
    selectedOption = index;
}

function nextQuestion() {
    if (selectedOption === null) {
        alert("Please select an option");
        return;
    }

    if (selectedOption === quizData[currentQuestion].correct) {
        score++;
    }

    currentQuestion++;

    if (currentQuestion < quizData.length) {
        loadQuestion();
    } else {
        showResult();
    }
}

function showResult() {
    quizEl.classList.add("hidden");
    resultEl.classList.remove("hidden");
    scoreText.textContent = `You scored ${score} out of ${quizData.length}`;
}

function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    resultEl.classList.add("hidden");
    quizEl.classList.remove("hidden");
    loadQuestion();
}
