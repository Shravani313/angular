let students = []; // array to store student records

function addStudent() {
    const name = document.getElementById("name").value.trim();
    const marks = parseInt(document.getElementById("marks").value);

    if (name === "" || isNaN(marks) || marks < 0 || marks > 100) {
        alert("Please enter valid student details");
        return;
    }

    let grade = calculateGrade(marks);

    // add student object to array
    students.push({
        name: name,
        marks: marks,
        grade: grade
    });

    displayStudents();

    // clear inputs
    document.getElementById("name").value = "";
    document.getElementById("marks").value = "";
}

// grade calculation using if-else
function calculateGrade(marks) {
    if (marks >= 90) {
        return "A";
    } else if (marks >= 75) {
        return "B";
    } else if (marks >= 60) {
        return "C";
    } else if (marks >= 40) {
        return "D";
    } else {
        return "F";
    }
}

// display records using loop
function displayStudents() {
    const table = document.getElementById("studentTable");
    table.innerHTML = "";

    for (let i = 0; i < students.length; i++) {
        let row = `
            <tr>
                <td>${students[i].name}</td>
                <td>${students[i].marks}</td>
                <td>${students[i].grade}</td>
            </tr>
        `;
        table.innerHTML += row;
    }
}
